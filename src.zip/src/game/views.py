from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages


# Tela inicial
@login_required
def start_view(request):
    messages.info(request, "Tela de Início...")
    return render(request, "game/start.html")


# Tela de estado
@login_required
def state_view(request):
    return render(request, "game/board.html")


# Rolar os dados
@login_required
def roll_view(request):
    if request.method == "POST":
        messages.error(request, "Ação inválida.")
        return redirect("game:state")

    messages.success(request, "Dados rolando...")
    return redirect("game:state")
