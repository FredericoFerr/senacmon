from django.contrib.auth.decorators import login_required
from django.shortcuts import render


@login_required
def balance_view(request):
    return render(request, template_name="wallet/balance.html", context={"balance": 100})


@login_required()
def transactions_view(request):
    return render(request, template_name="wallet/transactions.html", context={"transactions": []})


from django.shortcuts import render

# Create your views here.
